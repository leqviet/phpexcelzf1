<?php
spl_autoload_unregister(array('Zend_Loader_Autoloader','autoload'));
require_once('PHPExcel/Classes/PHPExcel.php');
class Default_Model_Excel extends PHPExcel
{


}
?>