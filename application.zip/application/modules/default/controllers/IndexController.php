<?php
spl_autoload_unregister(array('Zend_Loader_Autoloader','autoload'));
require_once('PHPExcel.php');
class IndexController extends Zend_Controller_Action{
	public function indexAction(){

    }	
    
    public function exportAction() {
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        $objExcel = new PHPExcel;
        $objExcel->setActiveSheetIndex(0);
        $sheet = $objExcel->getActiveSheet()->setTitle('10A1');
    
        $rowCount = 1;
        $sheet->setCellValue('A'.$rowCount,'Họ tên');
        $sheet->setCellValue('B'.$rowCount,'Toán');
        $sheet->setCellValue('C'.$rowCount,'Lý');
        $sheet->setCellValue('D'.$rowCount,'Hóa');
    
        //$result = $mysqli->query("SELECT diem.name,toan,ly,hoa FROM diem INNER JOIN lop ON lop.id=diem.id_lop WHERE lop.name='10A1'");
        //while($row = mysqli_fetch_array($result)){
            //$rowCount++;
            $sheet->setCellValue('A2','Lê Thanh Tài');
            $sheet->setCellValue('B2','10');
            $sheet->setCellValue('C2','10');
            $sheet->setCellValue('D2','10');
        //}
    
        $objWriter = new PHPExcel_Writer_Excel2007($objExcel);
        $filename = 'export.xlsx';
        $objWriter->save($filename);
    
        header('Content-Disposition: attachment; filename="' . $filename . '"');  
        header('Content-Type: application/vnd.openxmlformatsofficedocument.spreadsheetml.sheet');  
        header('Content-Length: ' . filesize($filename));  
        header('Content-Transfer-Encoding: binary');  
        header('Cache-Control: must-revalidate');  
        header('Pragma: no-cache');  
        readfile($filename);  
        return;
	
    }
    
    public function exporttestAction() {
        date_default_timezone_set('Asia/Ho_Chi_Minh');
$data = [
['Nguyễn Khánh Linh', 'Nữ', '500k'], 
['Ngọc Trinh', 'Nữ', '700k'], 
['Tùng Sơn', 'Không xác định', 'Miễn phí'], 
['Kenny Sang', 'Không xác định', 'Miễn phí']
];
	//Khởi tạo đối tượng
$excel = new PHPExcel();
	//Chọn trang cần ghi (là số từ 0->n)
$excel->setActiveSheetIndex(0);
	//Tạo tiêu đề cho trang. (có thể không cần)
$excel->getActiveSheet()->setTitle('demo ghi dữ liệu');

	//Xét chiều rộng cho từng, nếu muốn set height thì dùng setRowHeight()
$excel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('C')->setWidth(30);

	//Xét in đậm cho khoảng cột
$excel->getActiveSheet()->getStyle('A1:C1')->getFont()->setBold(true);
	//Tạo tiêu đề cho từng cột
	//Vị trí có dạng như sau:
	/**
	 * |A1|B1|C1|..|n1|
	 * |A2|B2|C2|..|n1|
	 * |..|..|..|..|..|
	 * |An|Bn|Cn|..|nn|
	 */
	$excel->getActiveSheet()->setCellValue('A1', 'Tên');
	$excel->getActiveSheet()->setCellValue('B1', 'Giới Tính');
	$excel->getActiveSheet()->setCellValue('C1', 'Đơn giá(/shoot)');
	// thực hiện thêm dữ liệu vào từng ô bằng vòng lặp
	// dòng bắt đầu = 2
	$numRow = 2;
	foreach($data as $row){
		$excel->getActiveSheet()->setCellValue('A'.$numRow, $row[0]);
		$excel->getActiveSheet()->setCellValue('B'.$numRow, $row[1]);
		$excel->getActiveSheet()->setCellValue('C'.$numRow, $row[2]);
		$numRow++;
	}
	// Khởi tạo đối tượng PHPExcel_IOFactory để thực hiện ghi file
	// ở đây mình lưu file dưới dạng excel2007 và cho người dùng download luôn
	header('Content-type: application/vnd.ms-excel');
	header('Content-Disposition: attachment; filename="data.xlsx"');
	PHPExcel_IOFactory::createWriter($excel, 'Excel2007')->save('php://output');
	return;
	
	}
}


